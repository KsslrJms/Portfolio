/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.csc454hw3;

import java.util.ArrayList;



/**
 *
 * @author ksslr
 */
abstract class Model {
    ArrayList<Pipe> inputs;
    Pipe out;
    void setIn(Pipe i){
        
    }
    void setOut(Pipe o){
        
    }
    void delta(){
        
    }
    void lambda(){
        
    }
    void print(){
        
    }
}
